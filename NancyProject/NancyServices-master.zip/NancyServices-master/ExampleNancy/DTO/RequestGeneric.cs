﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExampleNancy.DTO
{
    public class RequestGeneric
    {
        public String Key { get; set; }
        public String Object { get; set; }


    }
}
